let scrollEventHandler = function() {
            window.scroll(0, window.pageYOffset)
        };
        window.addEventListener("scroll", scrollEventHandler, false);