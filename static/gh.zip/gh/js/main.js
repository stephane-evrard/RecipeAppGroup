// document.addEventListener("click", function(event) {
//     event.preventDefault()
//     if (document.getElementById("fav").innerHTML = "add to favorites") {
//         alert('added to favorites')
//     } else {
//         document.getElementById("fav").innerHTML = "add to favorites";
//         alert('removed from favorites')
//     }

// });